_color)
        ship.blitme()
